// Top-level build file for the Gobelino Agent (Device Owner MDM agent).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
